title: SpringBoot高级案例之参数校验
date: '2019-11-01 22:43:05'
updated: '2019-11-01 23:45:55'
tags: [SpringBoot]
permalink: /articles/2019/11/01/1572619385651.html
---
![](https://img.hacpai.com/bing/20190322.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 一.前言
 在开发过程中，特别是如今微服务大势所趋去背景下，要求提供一个安全，健壮的REST服务，因此对接接口数据进行校验是必须工作。  
 在Springboot中提供两种校验方式，分为Spring Validation验证框架和Hibernate Validator，Spring Validation验证框架对参数的验证机制提供了@Validated（Spring's JSR-303 规范，是标准 JSR-303 的一个变种），Hibernate Validator 提供了 @Valid（标准JSR-303规范）

# 二.Hibernate Valid 参数校验

Hibernate Validator 提供了 JSR 303 规范中所有内置 constraint 的实现，除此之外还有一些附加的 constraint。

在pom.xml里添加依赖

```
<dependency>  
	<groupId>javax.validation</groupId>  
	<artifactId>validation-api</artifactId>  
</dependency>  
<dependency>  
	<groupId>org.hibernate</groupId>  
	<artifactId>hibernate-validator</artifactId>  
</dependency>
```

JSR 303 校验框架注解类：  
![827161201610221502099671863141332.png](https://img.hacpai.com/file/2019/11/827161201610221502099671863141332-d50eacc7.png)


Hibernate Validator扩展注解类：

• @Email 被注释的元素必须是电子邮箱地址  
• @Length 被注释的字符串的大小必须在指定的范围内  
• @NotEmpty 被注释的字符串的必须非空  
• @Range 被注释的元素必须在合适的范围内

校验结果保存在BindingResult或Errors对象中

• spring-boot-starter-web包里面有`hibernate-validator`包，不需要引用hibernate validator依赖
• 这两个类都位于org.springframework.validation包中  
• 需校验的表单对象和其绑定结果对象或错误对象是成对出现的  
• Errors接口提供了获取错误信息的方法，如getErrorCount()获取错误的数量， getFieldErrors(String field)得到成员属性的校验错误列表  
• BindingResult接口扩展了Errors接口，以便可以使用Spring的org.springframeword.validation.Validator对数据进行校验，同时获取数据绑定结果对象的信息

```
@Data
public class Demo {

    @NotEmpty(message = "名字不能为空")
    @Size(min = 2, max = 6, message = "名字长度在2-6位") //字符串，集合，map限制大小
    @Length(min = 2, max = 6, message = "名字长度在2-6位")
    private String name;

    @Length(min = 3, max = 3, message = "pass 长度不为3")
    private String pass;

    @DecimalMin(value = "10", inclusive = true, message = "salary 低于10") // 被注释的元素必须是一个数字，其值必须大于等于指定的最小值
    private int salary;

    @Range(min = 5, max = 10, message = "range 不在范围内")
    private int range;

    @NotNull(message = "年龄不能为空")
    @Min(value = 18, message = "年龄不能小于18")
    @Max(value = 70, message = "年龄不能大于70")
    private int age;

    @Email
    private String email;

    @AssertTrue
    private boolean flag;

    @Past
    private Date birthday;

    @Future
    private Date expire;

    @URL(message = "url 格式不对")
    private String url;

    @AnnoValidator(value = "1,2,3")
    private String anno;
    //@Pattern(regex=,flag=)  被注释的元素必须符合指定的正则表达式

    @Size(min = 2, max = 6, message = "长度在2-6位") //字符串，集合，map限制大小
    private List<Integer> list;

}
```

# 三.Spring Validated 参数校验

Validated是 Spring 对 Valid 的封装，是 Valid 的加强版，支持更多特性  
![112510720190107144432885308081584.png](https://img.hacpai.com/file/2019/11/112510720190107144432885308081584-425bc952.png)

## 1.基本使用
在pom.xml里添加依赖，如果你的项目是 SpringBoot2 项目就不用添加依赖了，web组件已经内置了这个依赖了

```
<dependency>  
	<groupId>javax.validation</groupId>  
	<artifactId>validation-api</artifactId>  
</dependency>  
```

只要类路径上有JSR-303实现(比如Hibernate验证器)，Bean validation 1.1支持的方法验证特性就会自动启用。这让bean方法可以用javax进行注释。对其参数和/或返回值的验证约束。使用这种带注释的方法的目标类需要在类型级别上使用@Validated注释进行注释，以便搜索它们的方法以找到内联约束注释。  
Validated 支持对 PathVariable 参数校验，以及 RequestParam 参数校验  

扩展javax.validation.Validator
```
package com.gitee.elead.web.validator;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidationException;
import javax.validation.executable.ExecutableValidator;
import javax.validation.metadata.BeanDescriptor;

import org.springframework.util.Assert;

/**
 * 拓展SpringValidatorAdapter以便于校验List<T>类型数据
 * {@link org.springframework.validation.beanvalidation.SpringValidatorAdapter
 *
 * @author luopeng
 */
public class ValidatorCollectionImpl implements javax.validation.Validator {

    private final javax.validation.Validator targetValidator = Validation.buildDefaultValidatorFactory().getValidator();

    //---------------------------------------------------------------------
    // Implementation of JSR-303 Validator interface
    //---------------------------------------------------------------------

    @SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
    public <T> Set<ConstraintViolation<T>> validate(T object, Class<?>... groups) {
        Assert.state(this.targetValidator != null, "No target Validator set");
        if (object instanceof Collection) {
            Set<ConstraintViolation<T>> constraintViolations = new HashSet<>();
            Collection collection = (Collection) object;
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                constraintViolations.addAll(this.targetValidator.validate((T) iterator.next(), groups));
            }
            return constraintViolations;
        }
        return this.targetValidator.validate(object, groups);
    }

    @Override
    public <T> Set<ConstraintViolation<T>> validateProperty(T object, String propertyName, Class<?>... groups) {
        Assert.state(this.targetValidator != null, "No target Validator set");
        return this.targetValidator.validateProperty(object, propertyName, groups);
    }

    @Override
    public <T> Set<ConstraintViolation<T>> validateValue(
            Class<T> beanType, String propertyName, Object value, Class<?>... groups) {
        Assert.state(this.targetValidator != null, "No target Validator set");
        return this.targetValidator.validateValue(beanType, propertyName, value, groups);
    }

    @Override
    public BeanDescriptor getConstraintsForClass(Class<?> clazz) {
        Assert.state(this.targetValidator != null, "No target Validator set");
        return this.targetValidator.getConstraintsForClass(clazz);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T unwrap(Class<T> type) {
        Assert.state(this.targetValidator != null, "No target Validator set");
        try {
            return (type != null ? this.targetValidator.unwrap(type) : (T) this.targetValidator);
        } catch (ValidationException ex) {
            // ignore if just being asked for plain Validator
            if (javax.validation.Validator.class == type) {
                return (T) this.targetValidator;
            }
            throw ex;
        }
    }

    @Override
    public ExecutableValidator forExecutables() {
        return targetValidator.forExecutables();
    }

}

```
在WebMvcConfigurer实现类覆盖getValidator()方法

```
@Configuration
public class WebMvcAutoConfiguration implements WebMvcConfigurer {

	@Override
	public Validator getValidator() {
		return new SpringValidatorAdapter(new ValidatorCollectionImpl());
	}
}
```

使用，但是注解必须写在类上：

```
@RestController
// 注解必须写在这里,参数校验不过会有 ConstraintViolationException 异常
@Validated
public class Valid2Controller {

    @GetMapping("valid4/{data}")
    public String getPathVariable(@Size(min = 3, max = 6) @PathVariable String data) {
        return data;
    }

    @GetMapping("valid4")
    public String getRequestParam(@Size(min = 3, max = 6) @RequestParam(value = "name", defaultValue = "0") String name) {
        return name;
    }

}


```

## 2.分组检验  
根据需要校验特定字段,应用场景：SpringDataJPA 中 save 方法没有 ID 字段就是保持新的数据，如果有 ID 字段就是跟新数据。  
使用方法：首先写一些接口，这里的接口是标记用的，就像 JsonView 一样。、  
BaseA

```
public interface BaseA {
}

```

BaseB

```
public interface BaseB {
}

```

被校验的实体类

```
@Data
public class UserSimple {

    //在AAAA分组时，判断不能为空
    @NotEmpty(groups = {BaseA.class})
    private String id;

    //name字段不为空，且长度在3-8之间
    @NotEmpty(message = "{user.name.notBlank}", groups = {BaseB.class})
    @Size(min = 3, max = 8, message = "{user.name.notBlank}", groups = {BaseB.class})
    private String name;

    private int age;

}

```

分组检验。当接口中(@RequestBody @Validated({BaseB.class}) 时只会校验实体类中被(groups = {BaseB.class})标记的字段。

```
@RestController
public class Valid1Controller {

    // {"name":"shao","pass":"333","salary":11,"range":6,"age":20,"email":"shaopro@qq.com","flag":true,"birthday":"2018-08-07T16:25:44.000+0000","expire":"2018-12-01T10:12:24.000+0000","url":"http://www.baidu.com","anno":"1","list":[1,2]}
    @PostMapping("valid1")
    public UserComplex postUser1(@RequestBody @Valid UserComplex user) {
        return user;
    }

    @PostMapping("valid2")
    public UserSimple postGroup(@RequestBody @Validated({BaseB.class}) UserSimple simpleUser) {
        return simpleUser;
    }

    @PutMapping("valid2")
    public UserSimple putGroup(@RequestBody @Validated({BaseA.class}) UserSimple simpleUser) {
        return simpleUser;
    }

}


```

# 四.参数校验异常处理

1.比较 low 的方式是在接口中使用 BindingResult 对象去接受这个校验结果  
例如：

```
    @RequestMapping("login")  
    public String login(@Valid User user, BindingResult result) {  
       if (result.hasErrors())  
           return "user/login";  
       return "redirect:/";  
    }  
    

```

先去判断是否有异常  
2.比较好方式是使用同一异常处理

```
@RestControllerAdvice
public class CheckAdvice {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * 请求的 JSON 参数在请求体内的参数校验
     *
     * @param e 异常信息
     * @return 返回数据
     * @throws JsonProcessingException jackson 的异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleBindException1(MethodArgumentNotValidException e) throws JsonProcessingException {
        e.getBindingResult().getAllErrors().forEach(System.out::println);
        return new ResponseEntity<>("cuowu:" + MAPPER.writeValueAsString(e.getBindingResult().getAllErrors()), HttpStatus.BAD_REQUEST);
    }

    /**
     * 请求的 URL 参数检验
     *
     * @param e 异常信息
     * @return 返回提示信息
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ConstraintViolationException.class)
    public String handleBindException2(ConstraintViolationException e) {
        e.getConstraintViolations().forEach(System.out::println);
        return "ConstraintViolationException";
    }

}


```

# 五.自定义参数校验

在很多情况下，JSR303 不能满足我们的校验需求，我们需要自定义一些校验逻辑，当然不是使用 if else 去判断。可以定义一些注解以及注解处理工具嵌入到 Spring 框架中自动调用。  
这里我们定义了注解 AnnoValidator 用来校验 anno 字段，只能存放1，2，3之中的一个字符串数字

```
    @AnnoValidator(value = "1,2,3")
    private String anno;

```

注解的内容：

```
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
//指定注解的处理类
@Constraint(validatedBy = AnnoValidatorClass.class)
public @interface AnnoValidator {

    String value();

    String message() default "AnnoValidator 不存在";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}


```

注解处理类

```
public class AnnoValidatorClass implements ConstraintValidator<AnnoValidator, Object> {

    private String value;

    @Override
    public void initialize(AnnoValidator constraintAnnotation) {
        this.value = constraintAnnotation.value();
    }

    @Override
    public boolean isValid(Object o, ConstraintValidatorContext constraintValidatorContext) {
        List<String> list = Arrays.asList(value.split(","));
        final AtomicBoolean flag = new AtomicBoolean(false);
        list.forEach(one -> {
            if (one.equals(o)) {
                flag.set(true);
            }
        });
        return flag.get();
    }

}


```

# 六.动态改变校验数据

经常某些字段的校验数据是动态改变的（例如手机的号码段扩充，某些操作的操作码增加），所以这些特殊情况我们不能讲校验的数据写死到代码中。下面展示了动态改变校验数据的方法。

自定义校验注解

```

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
//指定注解的处理类
@Constraint(validatedBy = DynamicHandler.class)
public @interface Dynamic {

    String value() default "";

    String message() default "Dynamic 不存在";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}


```

需要校验的实体类，假设 books 内的数据只能在某个范围内。

```
@Data
public class UserDynamic {

    private String name;

    @Dynamic
    private Set<String> books;

}

```

注解的处理类。需要注意的点：  
1.被 static 关键字修饰的字段是属于整个类的；  
2.存储可变字段的 Set 必须是线程安全的，当对容器中元素进行遍历同时增加数据时会抛出 fail-fast 错误。

```
public class DynamicHandler implements ConstraintValidator<Dynamic, Set<String>> {

    // 得用线程安全的容器,当对容器中元素进行遍历同时增加数据时会抛出 fail-fast 错误
    private volatile static CopyOnWriteArraySet<String> dynamicSet;

    @Override
    public boolean isValid(Set<String> set, ConstraintValidatorContext constraintValidatorContext) {
        return dynamicSet.containsAll(set);
    }

    @Override
    public void initialize(Dynamic constraintAnnotation) {
        // nothing to do
    }

    public static void setSet(CopyOnWriteArraySet<String> set) {
        DynamicHandler.dynamicSet = set;
    }
}


```

使用定时任务来模拟校验数据的改变，每十秒钟改变一下校验的数据。真实环境中应该是从数据库中获取。

```
@Slf4j
@Component
@EnableScheduling
public class DynamicSchedule {


    @Scheduled(fixedDelay = 10000)
    public void autoSync() {
        CopyOnWriteArraySet<String> dynamicSet = new CopyOnWriteArraySet<>();
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            dynamicSet.add(random.nextInt(10) + "");
        }
        DynamicHandler.setSet(dynamicSet);
        log.info(dynamicSet.toString());
    }

}

```

# 七. @Validated 和 @Valid 的区别
## 1. 分组

@Validated：提供了一个分组功能，可以在入参验证时，根据不同的分组采用不同的验证机制，这个网上也有资料，不详述。

@Valid：作为标准JSR-303规范，还没有吸收分组的功能。

## 2. 注解地方

@Validated：可以用在类型、方法和方法参数上。但是不能用在成员属性（字段）上

@Valid：可以用在方法、构造函数、方法参数和成员属性（字段）上

两者是否能用于成员属性（字段）上直接影响能否提供嵌套验证的功能。
## 3. 嵌套验证

在比较两者嵌套验证时，先说明下什么叫做嵌套验证。比如我们现在有个实体叫做Item：
```
public class Item {

    @NotNull(message = "id不能为空")
    @Min(value = 1, message = "id必须为正整数")
    private Long id;

    @NotNull(message = "props不能为空")
    @Size(min = 1, message = "至少要有一个属性")
    private List<Prop> props;
}
```

Item带有很多属性，属性里面有属性id，属性值id，属性名和属性值，如下所示：

```
public class Prop {

    @NotNull(message = "pid不能为空")
    @Min(value = 1, message = "pid必须为正整数")
    private Long pid;

    @NotNull(message = "vid不能为空")
    @Min(value = 1, message = "vid必须为正整数")
    private Long vid;

    @NotBlank(message = "pidName不能为空")
    private String pidName;

    @NotBlank(message = "vidName不能为空")
    private String vidName;
}
```

属性这个实体也有自己的验证机制，比如属性和属性值id不能为空，属性名和属性值不能为空等。

现在我们有个 ItemController 接受一个Item的入参，想要对Item进行验证，如下所示：

```
@RestController
public class ItemController {

    @RequestMapping("/item/add")
    public void addItem(@Validated Item item, BindingResult bindingResult) {
        doSomething();
    }
}
```

在上图中，如果Item实体的props属性不额外加注释，只有@NotNull和@Size，无论入参采用@Validated还是@Valid验证，Spring Validation框架只会对Item的id和props做非空和数量验证，不会对props字段里的Prop实体进行字段验证，也就是@Validated和@Valid加在方法参数前，都不会自动对参数进行嵌套验证。也就是说如果传的List中有Prop的pid为空或者是负数，入参验证不会检测出来。

为了能够进行嵌套验证，必须手动在Item实体的props字段上明确指出这个字段里面的实体也要进行验证。由于@Validated不能用在成员属性（字段）上，但是@Valid能加在成员属性（字段）上，而且@Valid类注解上也说明了它支持嵌套验证功能，那么我们能够推断出：@Valid加在方法参数时并不能够自动进行嵌套验证，而是用在需要嵌套验证类的相应字段上，来配合方法参数上@Validated或@Valid来进行嵌套验证。

我们修改Item类如下所示：

```
public class Item {

    @NotNull(message = "id不能为空")
    @Min(value = 1, message = "id必须为正整数")
    private Long id;

    @Valid // 嵌套验证必须用@Valid
    @NotNull(message = "props不能为空")
    @Size(min = 1, message = "props至少要有一个自定义属性")
    private List<Prop> props;
}
```

然后我们在ItemController的addItem函数上再使用@Validated或者@Valid，就能对Item的入参进行嵌套验证。此时Item里面的props如果含有Prop的相应字段为空的情况，Spring Validation框架就会检测出来，bindingResult就会记录相应的错误。

# 八. 总结
**@Validated：** 用在方法入参上无法单独提供嵌套验证功能。不能用在成员属性（字段）上，也无法提示框架进行嵌套验证。能配合嵌套验证注解@Valid进行嵌套验证。

**@Valid：** 用在方法入参上无法单独提供嵌套验证功能。能够用在成员属性（字段）上，提示验证框架进行嵌套验证。能配合嵌套验证注解@Valid进行嵌套验证。
